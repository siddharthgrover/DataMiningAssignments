#!/bin/bash

# Plot the graph
python3 Q2/q2.py "$1"