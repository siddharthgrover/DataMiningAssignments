README for Q2, HomeWork 3

We provide trained models as well as precomputed RWR values (for 10K iterations) in Q2/data/

Run:
    sh Q2.sh 1   :   to load the saved model and print RMSE on a random test data
    sh Q2.sh 0   :   to train a model from scratch and print RMSE on a random test data

If you wish to generate new ground truth RWR values, uncomment line 128 in Q2/q2.py