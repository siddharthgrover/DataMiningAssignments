import sys
import random
import numpy as np
import torch
import torch_geometric as tg
import torch_geometric.datasets
from tqdm import tqdm
import math

def RandomWalk(graph, iters=1e4):
    edges = np.array(graph.edge_index).T 
    N = graph.num_nodes

    G = np.zeros((N, N)).astype('int8')

    for edge in edges:
        G[edge[0]][edge[1]] = 1

    final_freq = []
    
    for source in tqdm(range(N)):
        freq = np.zeros(N)
        for _ in range(iters):
            src = source
            for i in range(4):
                dest_options = np.where(G[src]>0)[0]
                if len(dest_options) == 0:
                    break
                dest = np.random.choice(dest_options, 1)[0]
                src = dest
                freq[dest] += 1
        freq /= (4*iters)
        final_freq.append(freq)
    
    return np.stack(final_freq)

    
class EmbedModel(torch.nn.Module):
    def __init__(self, n_layers, input_dim, hidden_dim, output_dim, conv='gcn'):
        super().__init__()
        self.n_layers = n_layers
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        
        self.pre = torch.nn.Linear(self.input_dim, self.hidden_dim)
        
        if conv == 'gcn':
            make_conv = lambda:\
                tg.nn.GCNConv(self.hidden_dim, self.hidden_dim)
        elif conv == 'sage':
            make_conv = lambda:\
                tg.nn.SAGEConv(self.hidden_dim, self.hidden_dim)
        elif conv == 'gat':
            make_conv = lambda:\
                tg.nn.GATConv(self.hidden_dim, self.hidden_dim)
        else:
            assert False
            
        self.convs = torch.nn.ModuleList()
        for l in range(self.n_layers):
            self.convs.append(make_conv())
        
        self.post = torch.nn.Sequential(
            torch.nn.Linear(self.hidden_dim, self.hidden_dim),
            torch.nn.LeakyReLU(),
            torch.nn.Linear(self.hidden_dim, self.output_dim)
        )
    
    def forward(self, g):
        x = g.x
        edge_index = g.edge_index
        x = self.pre(x)
        for i in range(self.n_layers):
            x = self.convs[i](x, edge_index)
            x = torch.nn.functional.leaky_relu(x)        
        x = self.post(x)
        return x

    
class PredictionModel(torch.nn.Module):
    def __init__(self, input_dim, output_dim):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim

        self.mlp = torch.nn.Sequential(
                    torch.nn.Linear(self.input_dim*2, self.output_dim),
                    torch.nn.LeakyReLU(),
                    torch.nn.Linear(self.output_dim, 1),
                    torch.nn.LeakyReLU())
        
    def forward(self, x1, x2):
        X = torch.cat((x1, x2), dim=-1)
        return self.mlp(X).view(-1)
    
    def predict(self, x, data, ids):
        n = data[0].shape[0]
        preds = []
        for i in range(n):
            A = x[ids[i]]
            B = x[data[0][i].long()]
            A = A.expand(B.shape[0],A.shape[0])
            preds.append(self.forward(A,B))
        preds = torch.stack(preds)
        return preds
    
    def evaluate(self, preds, data):
#         weight = (1+5*data[1])*torch.ones(data[1].shape).to(device)
#         return torch.mean(weight * (preds-data[1])**2)**0.5
        return torch.nn.functional.mse_loss(preds,data[1])**0.5


##########################################################################################################################################

if __name__ == '__main__':
    
    use_saved = int(sys.argv[1])

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    trainfull = tg.datasets.Planetoid(root='./', name='Cora', split='random', num_train_per_class=50).data
    testfull = tg.datasets.Planetoid(root='./', name='Cora', split='random', num_test=1000).data
    
    torch.save(trainfull,"Q2/data/graph.pt")
    
    RWR = np.load('Q2/data/RWR_10K.npy')
#     RWR = RandomWalk(trainfull)
    
    test_ids = np.where(testfull.test_mask)[0]
    test_data = ([],[])
    n = len(test_ids)
    for i in range(n):
        v = np.sort(np.random.choice(test_ids[test_ids != test_ids[i]], size=10, replace=False))
        test_data[0].append(v)
        test_data[1].append(RWR[test_ids[i]][v])
    test_data = np.stack(test_data)
#     torch.save(test_data, "Q2/data/test_data.pt")
        
    # #* If use_saved == 1, then use the saved model to get the rmse on the test data
    if use_saved == 1 :
        
        dim = 32
        layers = 4
        epochs = 500
        lr = 0.001
        conv = 'gcn' # [gcn, sage, gat]
    
        embed_model = EmbedModel(layers, testfull.x.shape[1], dim, dim, conv).to(device)
        pred_model = PredictionModel(dim,dim).to(device)
        
        embed_model.load_state_dict(torch.load('Q2/data/%s_best_em_leaky.pt'%conv))
        pred_model.load_state_dict(torch.load('Q2/data/%s_best_pre_leaky.pt'%conv))
        
        test_data = torch.tensor(test_data, dtype=torch.float).to(device)
        test_ids = torch.tensor(test_ids).to(device)
        graph = torch.load('Q2/data/graph.pt').to(device)
    
        with torch.no_grad():
            test_loss = 0
            test_loader = tg.data.DataLoader([test_data], batch_size=1)
            for vbatch in test_loader:
                data = vbatch
                x = embed_model(graph)
                preds = pred_model.predict(x, data[0], test_ids)
            pred_model.evaluate(preds,data[0])
            print('Test Loss:',pred_model.evaluate(preds,data[0]).item())
            # print('Baseline: ',pred_model.evaluate(torch.zeros(data[0][0].shape).to(device), data[0]).item()) 
    
    else :

        #! NEW Data Generation
        train_ids = np.where(trainfull.train_mask)[0]
        train_data = ([],[])
        n = len(train_ids)
        for i in range(n):
            v = np.sort(np.random.choice(train_ids[train_ids != train_ids[i]], size=300, replace=False))
            train_data[0].append(v)
            train_data[1].append(RWR[train_ids[i]][v])
        train_data = np.stack(train_data)
#         torch.save(train_data, "Q2/data/train_data.pt")

        val_ids = np.where(trainfull.val_mask)[0]
        val_data = ([],[])
        n = len(val_ids)
        for i in range(n):
            v = np.sort(np.random.choice(val_ids[val_ids != val_ids[i]], size=20, replace=False))
            val_data[0].append(v)
            val_data[1].append(RWR[val_ids[i]][v])
        val_data = np.stack(val_data)
#         torch.save(val_data, "Q2/data/val_data.pt")        

        
        train_data, test_data, val_data = torch.tensor(train_data, dtype=torch.float).to(device), torch.tensor(test_data, dtype=torch.float).to(device), torch.tensor(val_data, dtype=torch.float).to(device)
        train_ids, test_ids, val_ids = torch.tensor(train_ids).to(device), torch.tensor(test_ids).to(device), torch.tensor(val_ids).to(device)
        graph = torch.load('Q2/data/graph.pt').to(device)
     
    
        #! Set The Parameters
        dim = 32
        layers = 4
        epochs = 500
        lr = 0.001
        conv = 'gcn' # [gcn, sage, gat]
    
        embed_model = EmbedModel(layers, graph.x.shape[1], dim, dim, conv).to(device)
        pred_model = PredictionModel(dim,dim).to(device)
        train_loader = tg.data.DataLoader([train_data], batch_size=1)
        val_loader = tg.data.DataLoader([val_data], batch_size=1)
        opt = torch.optim.AdamW([{'params': pred_model.parameters()},{'params': embed_model.parameters()}],
                            lr=lr, weight_decay=1e-3)
        scheduler = torch.optim.lr_scheduler.CyclicLR(opt, base_lr=0.0001, max_lr=0.001,step_size_up=50, cycle_momentum = False)
    
    
    #! Training the Model
        bar = tqdm(range(epochs))
        best_mse = math.inf

        for i in bar:
    
            with torch.no_grad():
                val_loss = 0
                for vbatch in val_loader:
                    data = vbatch
                    x = embed_model(graph)
                    val_loss += pred_model.evaluate(pred_model.predict(x, data[0], val_ids),data[0])
                    if (val_loss.item() < best_mse):
                        torch.save(embed_model.state_dict(),'Q2/data/%s_best_em_leaky.pt'%conv)
                        torch.save(pred_model.state_dict(),'Q2/data/%s_best_pre_leaky.pt'%conv)
                        best_mse = val_loss.item()
    
            loss = 0
            for batch in train_loader:
                data = batch
                x = embed_model(graph)
                loss += pred_model.evaluate(pred_model.predict(x, data[0], train_ids),data[0])

            opt.zero_grad()
            loss.backward()
            opt.step()
            scheduler.step()
            bar.set_postfix_str(f'train:{loss.item():.8f} val:{val_loss.item():.8f}')
        
        embed_model.load_state_dict(torch.load('Q2/data/%s_best_em_leaky.pt'%conv))
        pred_model.load_state_dict(torch.load('Q2/data/%s_best_pre_leaky.pt'%conv))

        with torch.no_grad():
            test_loss = 0
            test_loader = tg.data.DataLoader([test_data], batch_size=1)
            for vbatch in test_loader:
                data = vbatch
                x = embed_model(graph)
                preds = pred_model.predict(x, data[0], test_ids)
            print('Test Loss:',pred_model.evaluate(preds,data[0]).item())
            # print('Baseline: ',pred_model.evaluate(torch.zeros(data[0][0].shape).to(device), data[0]).item())
