import sys

def main () :
    
    args = sys.argv
    input_file = args[1]
    
    file = open (input_file, 'r')
    Lines = file.readlines()
    Lines = [line.rstrip() for line in Lines]
    file.close()

    newFile = open ('Q1/input_fsg.txt', 'w')

    i = 0
    cnt = 0

    node_vec = []
    node_dict = {}
    node_numbers = []

    while (i < len(Lines)) :
    
    
        if (Lines[i] == ""):
            i += 1
    
        if (i >= len(Lines)) :
            break 
    
        node_vec.clear()
        # node_dict.clear()
        node_numbers.clear()
    
        st = Lines[i]    
        i += 1
    
        kk = "t # " + str(cnt)
        newFile.write(kk+"\n")
    
        num_nodes = int (Lines[i])
        i += 1
    
        for j in range(num_nodes):
            lbl = Lines[i]
            node_numbers.append(j)
            node_vec.append(lbl)
            if lbl not in node_dict:
                node_dict[lbl] = len(node_dict)
            # p = "v " + str(j) + " " + lbl
            # newFile.write(p+"\n") 
            # print (p)
            i += 1
    
        for q in range(len(node_numbers)):
            p = "v " + str(node_numbers[q]) + " " + str(node_dict[node_vec[q]])
            newFile.write(p+"\n")
    
        num_edges = int (Lines[i])
        i += 1
    
        for j in range(num_edges):
            scr, dest, edlbl =  map(str, Lines[i].split())  
            q = "u " + scr + " " + dest + " " + edlbl
            newFile.write(q+"\n")
            # print (q)
            i += 1
        
        cnt += 1
        # break
    
    newFile.close()

if __name__ == "__main__":
    main()