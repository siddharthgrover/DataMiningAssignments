# Plot support threshold vs runnning times of Apriori and FP-tree algorithm.
import matplotlib.pyplot as plt
import timeit
import sys
import math

def count_trans () :
    
    args = sys.argv
    input_file = args[2]
    
    file = open (input_file, 'r')
    Lines = file.readlines()
    Lines = [line.rstrip() for line in Lines]
    file.close()

    i = 0
    cnt = 0
       
    while (i < len(Lines)) :

        if (Lines[i] == ""):
            i += 1

        if (i >= len(Lines)) :
            break 

        i += 1
    
        num_nodes = int (Lines[i])
        i += 1
    
        for j in range(num_nodes):
            i += 1
    
        num_edges = int (Lines[i])
        i += 1
    
        for j in range(num_edges):
            i += 1
        
        cnt += 1

    return cnt

def main () :
    
    args = sys.argv
    plot_name = args[1]

    total = count_trans()
    # print ("Total Count is",total)
        
    supports_plot = [95, 50, 25, 10, 5]
    # Replace with number of transactions
    supports = []

    for ss in supports_plot:
        supcnt = math.ceil (ss/100 * total)
        supports.append(supcnt)

    # print (supports)

    times_fsg = []
    times_gaston = []
    times_gspan = []
    
    for i in range(len(supports)):
        
        cmd_gaston = str(supports[i])
        res_gaston = 'subprocess.run(["Q1/gaston-1.1/gaston", "{0}", "Q1/input_gaston.txt"])'.format(cmd_gaston)
        k_gaston   = timeit.timeit(res_gaston , setup= 'import subprocess' , number=1)
        times_gaston.append(k_gaston)
        
        cmd_fsg = "-s " + str(supports_plot[i])
        res_fsg = 'subprocess.run(["Q1/pafi-1.0.1/Linux/fsg", "{0}", "Q1/input_fsg.txt"])'.format(cmd_fsg)
        k_fsg   = timeit.timeit(res_fsg , setup= 'import subprocess' , number=1)
        times_fsg.append(k_fsg)

        cmd_gspan1 = str((supports_plot[i]/100))
        res_gspan = 'subprocess.run(["Q1/gSpan-64","-f", "Q1/input_gaston.txt","-s", "{0}"])'.format(cmd_gspan1)
        k_gspan   = timeit.timeit(res_gspan , setup= 'import subprocess' , number=1)
        times_gspan.append(k_gspan)
    
    
        plt.plot(supports_plot[:i+1] , times_gaston, color ='tab:orange', label = 'Gaston')
        plt.plot(supports_plot[:i+1] , times_fsg, color ='tab:blue', label = 'FSG')
        plt.plot(supports_plot[:i+1] , times_gspan, color ='tab:green', label = 'gSpan')
        plt.xlabel('Support Threshold (Percentage)')
        plt.ylabel('Execution Time (s)')
        plt.legend(loc='upper right')
        plt.savefig(plot_name+".png")
        plt.close()
    


if __name__ == "__main__":
    main()