Question 1

	Q1.sh runs the preprocessing steps on the dataset followed by running the code for different mining algorithms and plotting the time.

	script_gaston contains the code to convert the input data into required format for gSpan and Gaston. We also convert the node labels to int, as it is a requirement for Gaston algorithm. It can be run using the following command ‘ python3 Q1/script_gaston.py input_file_path ’. The output file would be saved as ‘Q1/input_gaston.txt’.

	script_fsg contains the code to convert the input data into required format for FSG. It can be run using the following command ‘ python3 Q1/script_fsg.py input_file_path ’. The output file would be saved as ‘Q1/input_fsg.txt’.

	plot.py runs the different mining algorithms on input data and plots the time and saves it in the required format. It can be run as ‘python3 Q1/plot.py plot_name input_file’

Question 2

	Q2.sh runs 100 queries for different KNN methods namely KD-tree, M-tree and sequential.

	In kdtree.py, we use scikit's version of KD-tree. I use the max leaf size = 50.
	
	mtree_helper.py and mtree.py is used to run M-Tree. We use the implementation provided by Thomas Burette at https://github.com/tburette/mtree
	We again use the leaf size = 50.

	sequential.py contains code for naive algorithm.

	q2.py runs all the queries for all the methods and plots the mean and std graph.
	We need args to run this. first argument in the absoulte path of the dataset. second is the plot filename

	For e.g. , we can run using
	python q2.py /path/to/dataset plotname
