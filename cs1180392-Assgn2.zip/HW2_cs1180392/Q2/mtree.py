import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

from mtree_helper import MTree
import random
import time

def distance(x, y):
    sum = 0.
    for i in range(len(x)):
        sum += (x[i]-y[i])**2
    return sum    
    
def generate_tree(train_data):
    print("generating m-tree for dim={}".format(train_data.shape[1]))    
    tree = MTree(distance, max_node_size=50)
    for i in range(len(train_data)):
        tree.add(tuple(train_data[i]))
    return tree
    
def sample_indexes(total, num=100):
    return random.sample(range(total), num)

def time_for_dim(train_data, num=100, k=5):
    print("running queries for dim={}".format(train_data.shape[1]))
    tree = generate_tree(train_data)
    times = []
    idxs = sample_indexes(len(train_data), num=num)

    for x in idxs:
        point = train_data[x]
        start = time.time()
        res = tree.search(point, k=k)
        ttaken = time.time() - start
        times.append(ttaken)

    times = np.array(times)
    return np.mean(times), np.std(times)

def get_std_mean_arr(data_list):
    print("Now running for M-tree")
    means = []
    stds = []
    for data in data_list:
        m, s = time_for_dim(data)
        means.append(m)
        stds.append(s)
    return means, stds 