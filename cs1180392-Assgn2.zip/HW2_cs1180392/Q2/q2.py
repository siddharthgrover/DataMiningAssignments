import numpy as np

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt

from kdtree import get_std_mean_arr as kdtree_generator
from mtree import get_std_mean_arr as mtree_generator
from sequential import get_std_mean_arr as seq_generator

import time

import sys

def generate_pca_data(x, data):
    data_list = []
    for i in x:
        print("generating pca data for dim={}".format(i))
        pca  = PCA(n_components=i)
        pca_data = pca.fit_transform(data)
        data_list.append(pca_data)
    return data_list

def plot(x_labels, means, stds, label):
    mean = [d*1e3 for d in means]
    std = [x*1e3 for x in stds]
    # print(mean, std)
    plt.errorbar(x_labels, mean, yerr=std, label=label, uplims=True, lolims=True)

if __name__ == "__main__":

    data_path = "image_data.dat"
    fname = "plot"

    data_path, fname = sys.argv[1], sys.argv[2]

    start = time.time()
    dims = [2, 4, 10, 20]
    
    # load_data
    print("reading data")
    file = open(data_path, 'r')
    Lines = file.readlines()

    # # train_data = []
    # # for i in range(100):
    # #     y = file.readline()
    # #     # print(y)
    # #     train_data.append(list(map(float, y.split())))
    
    train_data = [ list(map(float, line.split())) for line in Lines]
    train_data = np.array(train_data)
    train_data = StandardScaler().fit_transform(train_data)

    pca_data_list = generate_pca_data(dims, train_data)

    # kd_mean, kd_std = kdtree_generator(pca_data_list)
    # m_mean, m_std = mtree_generator(pca_data_list)
    s_mean, s_std = seq_generator(pca_data_list)

    # print(kd_mean, kd_std)
    # print(m_mean, m_std)
    print(s_mean, s_std)

    # s_mean = [1.2878126502037048, 2.2334290170669555, 4.753851466178894, 8.623167684078217]
    # s_std = [0.00407696615915021, 0.004184206433342196, 0.12325215725225501, 0.03265398245131975]

    # kd_mean = [7.047414779663085e-05, 7.42793083190918e-05, 0.0007696747779846191, 0.010270211696624756]
    # kd_std = [0.00015593, 4.078692316779713e-05, 0.000471582, 0.0071116]

    # m_mean = [0.00135814, 0.00837544, 0.0806392, 0.376546099]
    # m_std = [0.000466, 0.002839, 0.03893342, 0.233964]

    # plot values
    fig = plt.figure()
    plt.xlabel('Dimentions')
    plt.ylabel('Time (ms)')

    # plot(dims, kd_mean, kd_std,'kdtree')
    # plot(dims, m_mean, m_std,'mtree')
    plot(dims, s_mean, s_std,'sequential')

    plt.legend()
    plt.savefig(fname + '.png')

    print("time_taken", time.time() - start)