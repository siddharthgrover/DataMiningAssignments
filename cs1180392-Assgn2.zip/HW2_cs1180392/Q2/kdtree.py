import numpy as np
from sklearn.neighbors import BallTree

import random
import time

def generate_tree(train_data):  
    print("generating kd-tree for dim={}".format(train_data.shape[1]))  
    tree = BallTree(train_data, leaf_size=50)
    return tree
    
def sample_indexes(total, num=100):
    return random.sample(range(total), num)

def time_for_dim(train_data, num=100, k=5):
    print("running queries for dim={}".format(train_data.shape[1]))
    tree = generate_tree(train_data)
    times = []
    idxs = sample_indexes(train_data.shape[0], num=num)

    for x in idxs:
        point = train_data[x]
        start = time.time()
        res = tree.query(point.reshape(1, -1), k=k)
        ttaken = time.time() - start
        times.append(ttaken)

    times = np.array(times)
    return np.mean(times), np.std(times)

def get_std_mean_arr(data_list):
    print("Now running for KD-tree")
    means = []
    stds = []
    for data in data_list:
        m, s = time_for_dim(data)
        means.append(m)
        stds.append(s)
    return means, stds