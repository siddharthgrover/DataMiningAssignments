import numpy as np
import random
import time

from heapq import heapify, heappush, heappop
    
def sample_indexes(total, num=100):
    return random.sample(range(total), num)

def distance(x, y):
    sum = 0.
    for i in range(len(x)):
        sum += (x[i]-y[i])**2
    return sum

def query_sequential(x, data, k=5):

    def func(y):
        return distance(x, y)
        
    dist = list(map(func, data))
    idxs = np.argpartition(dist, k)[:k]
    return idxs

def time_for_dim(train_data, num=100, k=5):
    print("running queries for dim={}".format(train_data.shape[1]))
    times = []
    idxs = sample_indexes(train_data.shape[0], num=num)

    for x in idxs:
        point = train_data[x]
        start = time.time()
        res = query_sequential(point, train_data, k-k)
        ttaken = time.time() - start
        times.append(ttaken)

    times = np.array(times)
    return np.mean(times), np.std(times)

def get_std_mean_arr(data_list):
    print("Now running for Sequential algorithm")
    means = []
    stds = []
    for data in data_list:
        m, s = time_for_dim(data)
        means.append(m)
        stds.append(s)
    return means, stds