#!/bin/bash

# Run all the Preproccessing Files
python3 Q1/script_gaston.py "$1"
python3 Q1/script_fsg.py "$1"

# Plot the graph
python3 Q1/plot.py "$2" "$1"