## Frequent Itemset Mining

As part of this assignment we have implemented Apriori and Prefix Spain Algorithm. We have also compared the running times of Fp-Tree and Apriori algorithms for differernt threshold.

### Commands

#### Compile The Code

```bash
.compile.sh
```

#### Running Apriori Algorithm

```bash
./2018CS10392.sh  -apriori <input-dataset> <support-threshold(percent)> <output-file>
```

#### Ploting the Running Times of Apriori vs Fp-Tree Algorithm

```bash
./2018CS10392.sh <input-dataset> -plot
```

#### Run Prefix-Span Algorithm

```bash
./2018CS10392.sh -prefixspan <input-dataset> <support-threshold(percent)> <output-file>
```

### Assumptions 

**Apriori:**

In the output of the Apriori algorithm, an extra line is printed after the frequent itemsets are mined.
   
**Prefix Span:**

Pre-Processing done on input file:

- We prune the first few lines that explain the structure of "path_finished.tsv"
- We replace all the backspaces with the corresponding articles
- Rest of the file is left intact inlcuding keeping semi-colon seperators

We finally create paths_finished.dat after preprocessing the original file. Just to reiterate, In the preprocessed input file (which is given in the arguments) we have every subsequence in a new line and itemsets (or items in this case, since each itemset is of length 1) in a subsequence are semi-colon(;) separated

### Explaination 

We can observe from the plots that fp-tree is considerably faster than the Apriori algorithm on all support thresholds. This can be attributed to the following reasons:- 

1. Unlike the Apriori algorithm, Fp-growth algorithm does not have any candidate set generation step.
   
2. As we decrease the support threshold the running time of Apriori increases exponentially due to the large number of candidates we need to generate and check for frequency in the dataset. The running time of Fp-growth algorithm also increases, but we see that the rate is very much lower than that for the apriori algorithm.

3. For the Apriori algorithm we need several databases scan, but for Fp-growth we just need 2 scans to build the compressed data structure. 

4. Moreover the huge difference in magnitude of runtimes of both the algorithms can also be attributed to the extra optimization provided by the library implementation.


### Files  

1. 'apriori.cpp' :- Contains our implementation of the Apriori Algorithm.
2. 'compile.sh' :- Bash file to compile the code.
3. '2018CS10392.sh' :- Script to run different commands.
4. 'plot.py' :- Plot the running times of Fp-Tree vs Apriori Algorithm.
5. 'preprocess_prefixspan' :- Script used to preprocess the input file for prefix span.
6. 'sequence_mining.py' :- Code for prefix span mining algorithm.
