cd fpgrowth/fpgrowth/src; make all; cd -;
g++ apriori.cpp -O3 -o apriori -std=c++11
